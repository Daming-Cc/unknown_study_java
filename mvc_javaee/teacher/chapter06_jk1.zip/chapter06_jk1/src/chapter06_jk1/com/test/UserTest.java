package chapter06_jk1.com.test;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import chapter06_jk1.com.po.User;
import chapter06_jk1.com.util.MybatisUtils;

public class UserTest {

	public static void main(String[] args) {
		SqlSession session = MybatisUtils.getSession();
		List<User> list = session.selectList("chapter06_jk1.com.mapper.UserMapper.findAllUser");
		for(User u:list) {
			System.out.println(u);
		}

	}

}
