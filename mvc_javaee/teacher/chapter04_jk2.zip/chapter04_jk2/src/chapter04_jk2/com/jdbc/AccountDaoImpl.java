package chapter04_jk2.com.jdbc;

import org.springframework.jdbc.core.JdbcTemplate;

public class AccountDaoImpl implements AccountDao {
	//����JdbcTemplate�����Լ�setter ����
	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public int add(Account account) {
		String sql = "insert into account(username,balance) values(?,?)";
		//�����������洢sql��䵱�еĲ���
		Object[] obj = new Object[] {
				account.getUsername(),
				account.getBalance()
		};
		
		int num = jdbcTemplate.update(sql,obj);
		return num;
	}

}
