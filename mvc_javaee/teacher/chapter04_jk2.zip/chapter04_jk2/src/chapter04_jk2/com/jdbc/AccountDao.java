package chapter04_jk2.com.jdbc;

public interface AccountDao {
	public int  add(Account account);
}
