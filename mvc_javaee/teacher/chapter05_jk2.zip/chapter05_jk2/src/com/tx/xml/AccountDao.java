package com.tx.xml;

public interface AccountDao {
	//ת��
	public void transfer(String outUser,String inUser,Double money);
}
