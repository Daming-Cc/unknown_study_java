package com.utils;

import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/**
 * ������
 * @author Administrator
 *
 */
public class MybatisUtils {
	private static SqlSessionFactory sqlSessionFactory = null;
	//��ʼ��SqlsessionFactory����
	static {
		//ʹ��Mybatis�ṩ��Resources�����Mybatis�����ļ�
		try {
			Reader reader = Resources.getResourceAsReader("mybatis-config.xml");
			//����SqlSessionFactory
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	//��ȡSqlSession����ľ�̬����
	public static SqlSession getSession() {
		return sqlSessionFactory.openSession();
	}
}
