package com.test;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.po.Customer;
import com.utils.MybatisUtils;

public class MybatisTest {

	public static void main(String[] args) {
		//ͨ������������sqlSession
		SqlSession sqlSession = MybatisUtils.getSession();
		Customer c = new Customer();
		c.setUsername("a");
		//c.setJobs("teacher");
		List<Customer> list = sqlSession.selectList("com.mapper.CustomerMapper.findByNamdAndJobs",c);
		for(Customer cu:list) {
			System.out.println(cu);
		}
		

	}

}
