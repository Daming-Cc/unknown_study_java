package com.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.CustomerDao;

public class CustomerTest {

	public static void main(String[] args) {
		//����spring�����ļ�
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		//��ȡdao��bean
		CustomerDao dao = (CustomerDao) ac.getBean("customerDao");
		System.out.println(dao.findCustomerById(1));
	}

}
