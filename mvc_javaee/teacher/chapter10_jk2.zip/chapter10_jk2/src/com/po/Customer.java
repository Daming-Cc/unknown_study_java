package com.po;

public class Customer {
	private int id;//����
	private String usrename;//�û���
	private String jobs;//ְ��
	private String phone;//�绰
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsrename() {
		return usrename;
	}
	public void setUsrename(String usrename) {
		this.usrename = usrename;
	}
	public String getJobs() {
		return jobs;
	}
	public void setJobs(String jobs) {
		this.jobs = jobs;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", usrename=" + usrename + ", jobs=" + jobs + ", phone=" + phone + "]";
	}
	
}
