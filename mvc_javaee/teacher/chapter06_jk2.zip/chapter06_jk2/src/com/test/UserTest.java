package com.test;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.po.User;
import com.utils.MybatisUtils;

public class UserTest {

	public static void main(String[] args) {
		SqlSession sqlSession = MybatisUtils.getSession();
		List<User> list = sqlSession.selectList("com.mapper.UserMapper.findAll");
		for(User u:list) {
			System.out.println(u);
		}
		sqlSession.close();

	}

}
